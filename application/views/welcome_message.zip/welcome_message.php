
<h2 align="center">Welcome to Sistem Akademik MTSN</h2>

<div id="body" style="text-align:center">
	<div style="text-align:center"><img src="<?=base_url('assets/img/GAMBAR.jpg')?>" width="40%" height="30%"/></div>
	<h2>Visi</h2>
	<p>If you would like to edit this page you'll find it located at:</p>

	<h2>Misi</h2>
	<div>
		<ol>
			<li>aaaaa</li>
			<li>bbbbbb/li>
				<li>cccccc</li>
			</ol>
		</div>
</div>

		